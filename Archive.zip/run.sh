g++ project1.cpp -g -Wall && ./a.out
